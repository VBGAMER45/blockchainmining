var gulp         = require('gulp'),
    sass         = require('gulp-sass'),
    autoprefixer = require('gulp-autoprefixer'),
    pixrem       = require('gulp-pixrem'),
    concat       = require('gulp-concat'),
    uglify       = require('gulp-uglify'),
    del          = require('del'),
    plumber      = require('gulp-plumber');

gulp.task('html', function() {
    return gulp.src('src/*.html')
    .pipe(gulp.dest('dist'));
});

gulp.task('stylesheets', function() {
    return gulp.src('src/stylesheets/main.scss')
        .pipe(plumber({
            errorHandler: function(error) {
                console.log(error.message);
                this.emit('end');
            }
        }))
        .pipe(sass({
            outputStyle: 'compressed'
        }))
        .pipe(autoprefixer({
            browsers: ['last 2 versions'],
            cascade: false
        }))
        .pipe(pixrem())
        .pipe(gulp.dest('dist/css'));
});

gulp.task('images', function() {
    return gulp.src('src/assets/images/**/*')
        .pipe(gulp.dest('dist/assets/images/'));
});

gulp.task('webfonts', function() {
    return gulp.src('src/assets/webfonts/**')
        .pipe(gulp.dest('dist/assets/webfonts/'));
});

gulp.task('javascript', function() {
    return gulp.src('src/javascript/*.js')
        .pipe(concat('script.min.js'))
        .pipe(uglify())
        .pipe(gulp.dest('dist/js'));
});

gulp.task('vendor', function () {
    return gulp.src('src/javascript/vendor/*.js')
        .pipe(gulp.dest('dist/js/vendor'));
});

gulp.task('clean', function(cb) {
    del(['dist/css', 'dist/assets/images', 'dist/js'], cb)
});

gulp.task('default', ['clean'], function() {
    gulp.start('stylesheets', 'images', 'webfonts', 'javascript');
});

gulp.task('watch', ['html', 'stylesheets', 'images', 'webfonts', 'javascript', 'vendor' ], function() {

    gulp.watch('src/stylesheets/**/*.scss', ['stylesheets']);

    gulp.watch('src/*.html', ['html']);

    gulp.watch('src/assets/images/**/*', ['images']);

    gulp.watch('src/assets/webfonts/*', ['webfonts']);

    gulp.watch('src/javascript/*.js', ['javascript']);

    gulp.watch('src/javascript/vendor/*.js', ['vendor']);

});