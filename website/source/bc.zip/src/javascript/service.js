function service()
{
    var $service = $('.service');
    $service.each(function(i,e) {
        if (scrollbar.isVisible(e)) {
            if ($(e).attr('data-visible') == 'false') {
                $(e).attr('data-visible', 'true');
                serviceAnim($(e));
            }
        }
    });
}

function serviceAnim(service)
{
    var number = service.find('.service__nb');
    var numberCount = service.find('.service__nb span');
    var title = service.find('.service__title');
    var border = service.find('.service__border');
    var content = service.find('.service__content');
    var max = parseInt(number.attr('data-id'));
    
    TweenLite.set(number, { y: '200%', autoAlpha: 0});
    TweenLite.set(numberCount, { y: '200%', autoAlpha: 0});
    TweenLite.set(title, { x: '10%', autoAlpha: 0});
    TweenLite.set(border, { x: '-100%', autoAlpha: 0});
    TweenLite.set(content, { x: '10%', autoAlpha: 0});

    TweenLite.to(number, .3, { y: '0%', autoAlpha: 1, ease: Circ.easeOut});
    TweenLite.to(numberCount, .3, { y: '0%', autoAlpha: 1, delay: 0.3, ease: Circ.easeOut});
    TweenLite.to(title, .6, { x: '0%', delay: 0.6, autoAlpha: 1});
    TweenLite.to(border, .6, { x: '0%', delay: 1, autoAlpha: 1});
    TweenLite.to(content, .6, { x: '0%', delay: 1.4, autoAlpha: 1});
    numberAnim(numberCount, max);
    
}

function numberAnim(element, id)
{
    var count = { num: 9 };
    TweenLite.to(count, .4, { num: "-=" + ( count.num - id ), roundProps: "num", delay: .3, onUpdate: function () { $(element).text(count.num) }, ease: Linear.easeNone });
}
