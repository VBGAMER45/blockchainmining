var burger = {
    icon: document.getElementById('js-nav-button'),
    menu: document.getElementById('mobile-menu'),
    menuItems: document.getElementsByClassName('mobile-menu__nav__item'),
    line: document.querySelector('.burger__line')
}

function fixedHeader(offset) {
    var $header = $('.header[data-id="2"]');
    var $headerLogo = $header.find('.header__left');
    var $navItem = $header.find('.header__nav__item');

    $header.parent().css('height', $header.css('height'));

    
    if (scrollbar.isVisible($header.get(0))) {
        if ($header.attr('data-visible') == 'false') {

            TweenLite.set($headerLogo, { autoAlpha: 0, y: '30%' });
            TweenLite.set($navItem, { autoAlpha: 0, y: '200%' });

            TweenLite.to($headerLogo, .8, { autoAlpha: 1, y: '0%', ease: Back.easeInOut });
            $navItem.each(function (index, el) {
                TweenLite.to(el, .8, { autoAlpha: 1, y: '0%', delay: index * 0.15, ease: Back.easeInOut });
            });
            $header.attr('data-visible', 'true');
        }
    } else {
        $header.attr('data-visible', 'false');
    }

    if (offset > windowHeight) {
        $header[0].classList.add('fixed');
        $header[0].style.top = offset + 'px';
    } else {
        $header[0].classList.remove('fixed');
        $header[0].style.top = '0px';
        
    }
}

function mobileheader()
{
    if ( windowWidth <= 768 ) {
        var $header = $('.header[data-id="2"]');
        document.getElementById('body').appendChild(
            document.getElementById('mobile-header')
        );
        console.log('header -> ', $header);
    }
}


function toggleMenu()
{    
    burger.line.classList.toggle('burger__line--active');
    if (burger.line.classList.contains('burger__line--active')) {
        TweenLite.to(burger.menu, .6, { bottom: '0%'});
        TweenLite.delayedCall(.6, function() {
            for (var i = 0; i < burger.menuItems.length; i++) {
                TweenLite.set(burger.menuItems[i], { x: '40%' });
                TweenLite.to(burger.menuItems[i], .6, { autoAlpha: 1, x: '0%', delay: i * 0.1, ease: Back.easeOut});
            }
        });
    } else {
        for (var i = 0; i < burger.menuItems.length; i++) {
            TweenLite.to(burger.menuItems[i], .6, { autoAlpha: 0, x: '40%', delay: i * 0.1, ease: Back.easeOut });
        }
        TweenLite.delayedCall(.6, function () {
            TweenLite.to(burger.menu, .6, { bottom: '100%'});
        });
    }
}

function hideMenu()
{
    burger.line.classList.remove('burger__line--active');
    for (var i = 0; i < burger.menuItems.length; i++) {
        TweenLite.to(burger.menuItems[i], .6, { autoAlpha: 0, x: '40%', delay: i * 0.1, ease: Back.easeOut });
    }
    TweenLite.delayedCall(.6, function () {
        TweenLite.to(burger.menu, .6, { bottom: '100%'});
    });
}

$(document).on('click', '.mobile-menu__nav__item .navLink', function() {
    hideMenu();
});