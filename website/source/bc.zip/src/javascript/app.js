var scrollbar;
var windowHeight = window.innerHeight;
var windowWidth = window.innerWidth;


$(function() {
    initSmoothScrollbar();
    loader(); 
    hero();
    nav();
    mobileheader();
    $(document).on('click', '#js-nav-button', function () {
        toggleMenu();
    });
});

$(window).on('resize', function() {
    mobileheader();
})

function initSmoothScrollbar()
{
    var Scrollbar = window.Scrollbar;
    scrollbar = Scrollbar.init(document.querySelector('#scrollbar'));
    scrollbar.addListener(onScroll);
}

function onScroll(status) 
{
    fixedHeader(status.offset.y);
    activeNav(status.offset.y);
    cover(status.offset.y);
    coverBackground(status.offset.y);
    // console.log(status.offset.y);
    textBox();
    service();
}