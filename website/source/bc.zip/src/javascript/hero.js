function hero()
{
    $hero = $('#hero');
    $loader = $('#loader');
    setHeroElements($hero);
    var interval = setInterval(function() {
        if ($loader.attr('data-visible') == 'false') {
            animateHeroElements($hero);
            clearInterval(interval);
        }
    }, 100);
}

function setHeroElements(hero)
{
    var whiteBox = hero.find('.white-box');
    
    TweenLite.set(whiteBox, { scale: 2.2 });
}

function animateHeroElements(hero)
{
    var whiteBox = $(hero).find('.white-box');
    TweenLite.to(whiteBox, 1, { scale: 1, ease: Back.easeOut.config(1), onComplete: function () { textBox(); } });
    heroFooter(hero);
    heroHeader();
    heroImage(hero);
}

function heroHeader() {
    $header = $('header[data-id="1"]');
    $headerLogo = $header.find('.header__left');
    $navItem = $header.find('.header__nav__item');


    TweenLite.set($headerLogo, { autoAlpha: 0, y: '30%' });
    TweenLite.set($navItem, { autoAlpha: 0, y: '200%' });

    TweenLite.delayedCall( 1.1, function() {
        TweenLite.to($headerLogo, .8, { autoAlpha: 1, y: '0%', ease: Back.easeInOut });
        $navItem.each(function(index, el) {
            TweenLite.to(el, .8, { autoAlpha: 1, y: '0%', delay: index * 0.15, ease: Back.easeInOut});
        });
    });
}

function heroFooter(hero)
{
    var footerSocial = hero.find('.hero__footer--social');
    var footerRights = hero.find('.hero__footer--rights');

    TweenLite.set(footerSocial, { autoAlpha: 0, y: '200%' });
    TweenLite.set(footerRights, { autoAlpha: 0, y: '200%' });

    TweenLite.delayedCall(1.8, function () {
        TweenLite.to(footerSocial, .8, { autoAlpha: 1, y: '0%', ease: Back.easeInOut });
        TweenLite.to(footerRights, .8, { autoAlpha: 1, y: '0%', delay: 0.3, ease: Back.easeInOut });
    });

}

function heroImage(hero)
{
    var image = hero.find('.white-box__image');
    var imageOverlay = image.find('.white-box__image--overlay');
    TweenLite.set(image, { autoAlpha: 1});
    TweenLite.to(imageOverlay, 2, { bottom: '100%', ease: Bounce.easeOut, delay: 2});
}