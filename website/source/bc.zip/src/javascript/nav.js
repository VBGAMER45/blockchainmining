var lastId,
    topMenu = $('.header[data-id="2"]'),
    topMenuHeight = topMenu.outerHeight(),
    // All list items
    menuItems = topMenu.find("a.navLink"),
    // Anchors corresponding to menu items
    scrollItems = menuItems.map(function () {
        var item = $($(this).attr("href"));
        if (item.length) { return item; }
    });

function nav()
{
    $(document).on('click', 'a.navLink', function(e) {
        e.preventDefault();
        var href = $(this).attr("href"),
        hrefOffset = $(href).get(0).offsetTop,
        offsetTop = href === "#" ? 0 : hrefOffset - topMenuHeight * 1.4;
        console.log('href -> ', href);
        console.log('offsetTop -> ', offsetTop);
        
        scrollbar.scrollTo(0, offsetTop, 1500);
        
    });
}

function activeNav(offsetY)
{
    var fromTop = offsetY + topMenuHeight;
    // Get id of current scroll item
    var cur = scrollItems.map(function () {
        if ($(this).get(0).offsetTop - topMenuHeight < fromTop)
            return this;
    });
    // Get the id of the current element
    cur = cur[cur.length - 1];
    var id = cur && cur.length ? cur[0].id : "";
    
    if (lastId !== id) {
        lastId = id;
        // Set/remove active class
        $(menuItems)
            .parent().removeClass("active")
            .end().filter("[href='#" + id + "']").parent().addClass("active");
    }       
}