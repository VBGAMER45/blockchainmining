function textBox()
{
    $tb = $('.text-box[data-visible="false"]');
    $tbBgText = $tb.find('.text-box__bgtext span');
    $tbSubtitle = $tb.find('.text-box__subtitle');
    $tbTitle = $tb.find('.text-box__title');
    $tbContent = $tb.find('.text-box__content');

    $tb.each(function(index, el) {
        if (scrollbar.isVisible(el)) {
            if ($(el).attr('data-visible') === 'false') {
                TweenLite.set($tbBgText, { autoAlpha: 0, x: '10%' });
                TweenLite.set($tbSubtitle, { autoAlpha: 0, x: '50%' });
                TweenLite.set($tbTitle, { autoAlpha: 0, x: '10%' });
                TweenLite.set($tbContent, { autoAlpha: 0, x: '10%' });

                TweenLite.delayedCall(.6, function() {
                    TweenLite.to($tbBgText, .6, { autoAlpha: 1, x: '0%' });
                    TweenLite.to($tbSubtitle, .6, { autoAlpha: 1, x: '0%', delay: .3});
                    TweenLite.to($tbTitle, .6, { autoAlpha: 1, x: '0%', delay: .6});
                    TweenLite.to($tbContent, .6, { autoAlpha: 1, x: '0%', delay: 1.2});
                    $(el).attr('data-visible', 'true');
                });
            }
        }
        
    });
}