function loader(callback)
{
    $loader = $('#loader');
    hideLoader($loader, callback);
}

function hideLoader(loader, callback)
{
    var $body = $('#body');
    $body.imagesLoaded({ background: true }, function () {
        setTimeout(function() {
            loader.fadeOut(function() {
                loader.attr('data-visible', false);
                if (callback != null || callback != undefined) {
                    callback();
                }
            });
        }, 1000);
    });
}