function cover(offsetY)
{
    var $cover = $('.cover');
    var $coverBox = $cover.find('#white-stripe');
    if ($cover.length) {
        $cover.each(function(i,e) {
            if (scrollbar.isVisible(e)) {
                TweenLite.to($coverBox, .1, { delay: 0.1, y:  offsetY * -0.3 + 'px'});
            }
        });
    }
}

function coverBackground(offsetY) {
    var $cover = $('.cover');
    var offsetStart = (offsetY - $('.cover').offset().top) * -0.1;
    $cover.each(function (i, e) {
        var coverImg = $(e).find('.cover__image');
        if (scrollbar.isVisible(e)) {
            $(coverImg).css('background-position-y', offsetStart + 'px');
        }
    });
}